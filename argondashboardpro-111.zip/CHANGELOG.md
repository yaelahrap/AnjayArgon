# Changelog


## [1.0.0] 2018-12-11
### Original Release

## [1.1.0] 2019-27-06
### Boostrap Update, Libraries Update
- Bootstrap updated to `4.3.1`
- libraries updated to latest versions
- fixed _icons.scss calc()

## [1.1.1] 2019-05-08
### Index Page Technologies Aligned
